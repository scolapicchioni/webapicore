# Quickstart #3: User Authentication using OpenID Connect Implicit Flow

This quickstart adds support for interactive user authentication using the OpenID Connect implicit flow.