# Quickstart #5: OpenID Connect Hybrid Flow Authentication and API Access Tokens

This quickstart adds support for Google authentication.